cd /Users/apple/IdeaProjects/learning-rest-assured
mvn test
