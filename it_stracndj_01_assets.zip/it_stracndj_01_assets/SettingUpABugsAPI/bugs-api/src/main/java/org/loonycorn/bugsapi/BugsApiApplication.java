package org.loonycorn.bugsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugsApiApplication.class, args);
	}

}
