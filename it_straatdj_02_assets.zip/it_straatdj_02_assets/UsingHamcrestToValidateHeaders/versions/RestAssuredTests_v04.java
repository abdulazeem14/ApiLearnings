package org.loonycorn.restassuredtests;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.RestAssured;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateHeaders() {
        ObjectMapper objectMapper = new ObjectMapper();

        RestAssured.get(POSTS_URL)
                .then()
                .header("Report-To", (s) -> {
                    try {
                        return objectMapper.readTree(s).get("max_age").asInt();
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                }, equalTo(3600));

    }
}
