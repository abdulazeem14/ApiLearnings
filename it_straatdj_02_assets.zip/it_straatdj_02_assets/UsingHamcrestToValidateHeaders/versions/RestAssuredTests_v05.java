package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.hamcrest.number.OrderingComparison;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateDateHeaders() {
        RestAssured.get(POSTS_URL)
                .then()
                .header("Date", (dateString) -> {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss zzz");
                    LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);

                    // Get the year from the LocalDateTime object
                    return dateTime.getYear();
                }, equalTo(2024));

        RestAssured.get(POSTS_URL)
                .then()
                .header(
                        "Date",
                        (dateString) ->
                                LocalDate.parse(dateString, DateTimeFormatter.RFC_1123_DATE_TIME),
                        equalTo(LocalDate.now())
                );

    }
}
