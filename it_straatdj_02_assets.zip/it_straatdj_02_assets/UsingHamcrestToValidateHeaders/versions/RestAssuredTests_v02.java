package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateHeaders() {
        RestAssured.get(POSTS_URL)
                .then()
                .statusCode(200)
                .statusCode(allOf(greaterThanOrEqualTo(200), lessThanOrEqualTo(300)))
                .time(lessThan(5L), TimeUnit.SECONDS)
                .header("Content-Type", notNullValue())
                .header("Content-Type", equalTo("application/json; charset=utf-8"))
                .header("Connection", notNullValue())
                .header("Connection", equalTo("keep-alive"))
                .header("Etag", notNullValue())
                .header("Cache-Control", containsStringIgnoringCase("max-age=43200"))
                .header("Expires", equalTo("-1"))
                .header("X-Ratelimit-Limit", equalTo("1000"))
                .header("X-Ratelimit-Remaining", equalTo("999"))
                .header("X-Ratelimit-Reset", equalTo("1708483361"));
    }
}
