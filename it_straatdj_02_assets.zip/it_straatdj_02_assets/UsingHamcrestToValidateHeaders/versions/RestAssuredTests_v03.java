package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateHeaders() {
        RestAssured.get(POSTS_URL)
                .then()
                .header("Expires", Integer::parseInt, equalTo(-1))
                .header("X-Ratelimit-Limit", Integer::parseInt, equalTo(1000))
                .header("X-Ratelimit-Remaining", Integer::parseInt, greaterThan(0))
                .header("X-Ratelimit-Reset", Integer::parseInt, equalTo(1708483361));

    }
}
