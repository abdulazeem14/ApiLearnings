-----------------------------------------------
Using Hamcrest to validate headers
-----------------------------------------------

# Go to

https://jsonplaceholder.typicode.com/

# Click on 

/posts

# Show the response - we're only going to be using the headers in this response

# Right-click -> Inspect -> Network

# Refresh the page and show the response headers so we can compare as needed


# Go back to the RestAssuredTests.java file

------------------------------------
# Taking a look at the headers (v01)


import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;


public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateHeaders() {
        RestAssured.get(POSTS_URL)
                .peek();
    }
}

# Run and inspect the headers

------------------------------------
# Validing headers using matchers (v01)


# Now let's validate the status code using Matchers

        RestAssured.get(POSTS_URL)
                .then()
                .statusCode(200)

# Hit enter and then type .statusCode()

# Show the autocomplete that the statusCode() method accepts a matcher

# and then add this matcher

                .statusCode(greaterThanOrEqualTo(200));

# The code should look like this

        RestAssured.get(POSTS_URL)
                .then()
                .statusCode(200)
                .statusCode(greaterThanOrEqualTo(200));

# Run and show

# Update the matcher


                .statusCode(allOf(greaterThanOrEqualTo(200), lessThanOrEqualTo(300)));

# Run and show

# Add time

                .time(lessThan(5L), TimeUnit.SECONDS)

# Run and show


# Now start typing .header() and show that headers also accept Matchers

# Add these header checks

                .header("Content-Type", notNullValue())
                .header("Content-Type", equalTo("application/json; charset=utf-8"))
                .header("Connection", notNullValue())
                .header("Connection", equalTo("keep-alive"));


# Code now looks like this:

        RestAssured.get(POSTS_URL)
                .then()
                .statusCode(200)
                .statusCode(allOf(greaterThanOrEqualTo(200), lessThanOrEqualTo(300)))
                .header("Content-Type", notNullValue())
                .header("Content-Type", equalTo("application/json; charset=utf-8"))
                .header("Connection", notNullValue())
                .header("Connection", equalTo("keep-alive"));


# Run the test and show


# Add two more header checks

                .header("Etag", notNullValue())
                .header("Cache-Control", containsStringIgnoringCase("max-age=43200"));

# Run the test and show

# However when you use the regular Matcher you still get the value of the header as a string

# Add another line

                .header("Expires", equalTo(-1));

# Run and show the error

# Change Expires to a string and another example

                .header("Expires", equalTo("-1"))
                .header("X-Ratelimit-Limit", equalTo(1000));

# Run and show the error

# Basically we can only do string comparisons with the basic matcher

                .header("Expires", equalTo("-1"))
                .header("X-Ratelimit-Limit", equalTo("1000"))
                .header("X-Ratelimit-Remaining", equalTo("999"))
                .header("X-Ratelimit-Reset", equalTo("1708483361"));


# Run and show that this passes



------------------------------------
# Using advanced matchers (v03)

# Use function matchers


# Start with this

    @Test
    void validateHeaders() {
        RestAssured.get(POSTS_URL)
                .then()
    }

# Type .header() and show the function matcher option

# Now add this validation

                .header("Expires", s -> Integer.parseInt(s), equalTo(-1));

# Run and show

# Hover over the yellow, should say "Replace lambda with method reference"


# Can also just use the method reference instead of the lambda

                .header("Expires", Integer::parseInt, equalTo(-1));

# Run and show               

# Parse and check other integer fields

        RestAssured.get(POSTS_URL)
                .then()
                .header("Expires", Integer::parseInt, equalTo(-1))
                .header("X-Ratelimit-Limit", Integer::parseInt, equalTo(1000))
                .header("X-Ratelimit-Remaining", Integer::parseInt, greaterThan(0))
                .header("X-Ratelimit-Reset", Integer::parseInt, equalTo(1708483361));

# Run and show


------------------------------------
# Parse JSON using matchers (v04)


# Go to

https://mvnrepository.com/

# Search for 

jackson databind

# Copy over the dependency in pom.xml

<!-- https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind -->
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.16.1</version>
</dependency>


# Right click -> Maven -> Reload project

# Back to RestAssuredTests

# Use lambda to extract the max-age

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.RestAssured;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateHeaders() {
        ObjectMapper objectMapper = new ObjectMapper();

        RestAssured.get(POSTS_URL)
                .then()
                .header("Report-To", (s) -> {
                    try {
                        return objectMapper.readTree(s).get("max_age").asInt();
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                }, equalTo(3600));

    }
}

# Run and show


------------------------------------
# Validate date using matchers (v05)


import io.restassured.RestAssured;
import org.hamcrest.number.OrderingComparison;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String POSTS_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    void validateDateHeaders() {
        RestAssured.get(POSTS_URL)
                .then()
                .header("Date", (dateString) -> {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss zzz");
                    LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);

                    // Get the year from the LocalDateTime object
                    return dateTime.getYear();
                }, equalTo(2024));

    }
}

# Run and show

# Can also compare a different way

        RestAssured.get(POSTS_URL)
                .then()
                .header(
                        "Date",
                        (dateString) ->
                                LocalDate.parse(dateString, DateTimeFormatter.RFC_1123_DATE_TIME),
                        equalTo(LocalDate.now())
                );



























































