-----------------------------------------------
URL paths and parameters
-----------------------------------------------

# On the browser go to 

https://fakestoreapi.com/

# click on

GET /products
GET /products/1


# Change URL to see products

2, 4, 6

# Go back to the main page, click on

/products/categories

# Go back and click on

/products/category/jewelery

# Change to

https://fakestoreapi.com//products/category/electronics

https://fakestoreapi.com/products/category/men's%20clothing

'

# Go to the main page again and click on

products?limit=5


# Change limit

products?limit=2


# Go to the main page again and click on

/carts?userId=1


# Change URL

/carts?userId=1&limit=2


/carts?userId=2&limit=3


# Back to IntelliJ


-----------------------------------------------
# Specify URL paths without parameters (v01)

package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String PRODUCT_ONE_URL = "https://fakestoreapi.com/products/1";

    @Test
    public void testProducts() {
        RestAssured.get(PRODUCT_ONE_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));
    }
}


# Run and show

# Add some tests for some other products


    private static final String PRODUCT_TWO_URL = "https://fakestoreapi.com/products/2";
    private static final String PRODUCT_FIVE_URL = "https://fakestoreapi.com/products/5";



        RestAssured.get(PRODUCT_TWO_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(2));

        RestAssured.get(PRODUCT_FIVE_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(5));

# Run and show


# Add some category tests



    private static final String CATEGORY_JEWELLERY_URL = 
            "https://fakestoreapi.com/products/category/jewelery";

    private static final String CATEGORY_ELECTRONICS_URL = 
            "https://fakestoreapi.com/products/category/electronics";



    @Test
    public void testCategories() {
        RestAssured.get(CATEGORY_JEWELLERY_URL)
                .then()
                .statusCode(200);

        RestAssured.get(CATEGORY_ELECTRONICS_URL)
                .then()
                .statusCode(200);
    }

# Run and show

# Add URL with query parameters


    private static final String USER_ONE_LIMIT_FIVE_CART_URL = 
            "https://fakestoreapi.com/carts?userId=1&limit=5";
    private static final String USER_ONE_LIMIT_TWO_CART_URL = 
            "https://fakestoreapi.com/carts?userId=1&limit=2";



    @Test
    public void testCartUserAndLimit() {
        RestAssured.get(USER_ONE_LIMIT_FIVE_CART_URL)
                .then()
                .statusCode(200)
                .body("size()", is(5));

        RestAssured.get(USER_ONE_LIMIT_TWO_CART_URL)
                .then()
                .statusCode(200)
                .body("size()", is(2));
    }       


# Run and show

-----------------------------------------------
# Specify URL paths without parameters with concatenation (v02)

# Change the code bit by bit
# Replace the original product constants with this



    private static final String STORE_URL = "https://fakestoreapi.com";

    private static final String PRODUCT_ONE_PATH = "/products/1";
    private static final String PRODUCT_TWO_PATH = "/products/2";
    private static final String PRODUCT_FIVE_PATH = "/products/5";


# Replace testProducts() with this


    @Test
    public void testProducts() {
        RestAssured.get(STORE_URL + PRODUCT_ONE_PATH)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(STORE_URL + PRODUCT_TWO_PATH)
                .then()
                .statusCode(200)
                .body("id", equalTo(2));

        RestAssured.get(STORE_URL + PRODUCT_FIVE_PATH)
                .then()
                .statusCode(200)
                .body("id", equalTo(5));

    }


# Run only this test and show it passes

# Now replace the category constants

    private static final String CATEGORY_JEWELLERY_PATH =
            "/products/category/jewelery";

    private static final String CATEGORY_ELECTRONICS_PATH =
            "/products/category/electronics";


# Change the categories test like this


    @Test
    public void testCategories() {
        RestAssured.get(STORE_URL + CATEGORY_JEWELLERY_PATH)
                .then()
                .statusCode(200)
                .body("size()", is(4));

        RestAssured.get(STORE_URL + CATEGORY_ELECTRONICS_PATH)
                .then()
                .statusCode(200)
                .body("size()", is(6));
    }


# Run only the categories test and show

# Now update the cart URL like this

    private static final String USER_ONE_LIMIT_FIVE_CART_PARAMS =
            "/carts?userId=1&limit=5";
    private static final String USER_ONE_LIMIT_TWO_CART_PARAMS =
            "/carts?userId=1&limit=2";

# And the test like this


    @Test
    public void testCartUserAndLimit() {
        RestAssured.get(STORE_URL + USER_ONE_LIMIT_FIVE_CART_PARAMS)
                .then()
                .statusCode(200)
                .body("size()", is(5));

        RestAssured.get(STORE_URL + USER_ONE_LIMIT_TWO_CART_PARAMS)
                .then()
                .statusCode(200)
                .body("size()", is(2));
    }


# Run only the cart test and show


-----------------------------------------------
# Use unnamed path params (v03)


public class RestAssuredTests {

    private static final String SINGLE_PRODUCTS_URL = "https://fakestoreapi.com/products/{id}";

    @Test
    public void testProductsWithPathParams() {
        RestAssured.get(SINGLE_PRODUCTS_URL, 1)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(SINGLE_PRODUCTS_URL, 3)
                .then()
                .statusCode(200)
                .body("id", equalTo(3));

        RestAssured.get(SINGLE_PRODUCTS_URL, 11)
                .then()
                .statusCode(200)
                .body("id", equalTo(11));

    }
}


# Run the test and show

-----------------------------------------------
# Use multiple unnamed path params (v04)



public class RestAssuredTests {

    private static final String COMPONENT_ID_URL = "https://fakestoreapi.com/{component}/{id}";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured.get(COMPONENT_ID_URL, "products", 1)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(COMPONENT_ID_URL, "products", 11)
                .then()
                .statusCode(200)
                .body("id", equalTo(11));

        RestAssured.get(COMPONENT_ID_URL, "carts", 2)
                .then()
                .statusCode(200)
                .body("id", equalTo(2));

        RestAssured.get(COMPONENT_ID_URL, "carts", 6)
                .then()
                .statusCode(200)
                .body("id", equalTo(6));

    }

}


-----------------------------------------------
# Use named path params (v05)


# In RestAssured, given(), when(), and then() are part of the given-when-then structure, which is a common way to structure API tests. This structure helps in writing readable and organized test cases.

# given():

# The given() method is used to set up the preconditions or initial state for the test. This typically includes things like setting headers, specifying request parameters, or setting up the request body.
# It allows you to define the initial context of the HTTP request before sending it.
# You can chain methods like .contentType(), .header(), .param(), .body(), etc., to set up the request.
# when():

# The when() method is used to specify the action or behavior being tested. This is usually the HTTP request you're making to the API.
# It represents the action that you want to perform on the system being tested, such as sending an HTTP request.
# You can chain HTTP methods like .get(), .post(), .put(), .delete(), etc., after when() to specify the type of request.
# then():

# The then() method is used to define the expected outcomes or assertions of the test. This includes verifying the response status code, response body, headers, etc.
# It represents the expected outcome or result of the action performed in the when() section.
# You can chain methods like .statusCode(), .body(), .header(), .assertThat(), etc., after then() to specify the assertions you want to make on the response.
# It also provides methods like .extract(), .assertThat(), etc., to extract data from the response or perform additional assertions.


# Paste this in first

public class RestAssuredTests {

    private static final String COMPONENT_ID_URL = "https://fakestoreapi.com/{component}/{id}";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .pathParam("component", "products")
                    .pathParam("id", 1)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(1));

        RestAssured
                .given()
                    .pathParam("component", "products")
                    .pathParam("id", 4)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(4));


        RestAssured
                .given()
                    .pathParam("component", "carts")
                    .pathParam("id", 2)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                .body("id", equalTo(2));


        RestAssured
                .given()
                    .pathParam("component", "carts")
                    .pathParam("id", 6)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(6));

    }

}


# Hover over given() and show that it returns a RequestSpecification
# Hover over when() and show that it returns a RequestSpecification (syntactic sugar)
# Hover over then() and show that it returns a ValidatableResponse


# Run the test and show that it passes

-----------------------------------------------
# Use query params (v06)

# Note that there are no placeholders in the URL
# The query parameters are appended to the URL


public class RestAssuredTests {

    private static final String STORE_CART_URL = "https://fakestoreapi.com/carts";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .param("userId", 1)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(7));

        RestAssured
                .given()
                    .param("userId", 2)
                .when()
                    .get(STORE_CART_URL)
                    .peek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(7));

    }

}


# Run the test

# Search for "id" in the response

# Should be 7 + 7 = 14 instances


-----------------------------------------------
# Use multiple query params (v07)


# Add the limit param

                    .param("limit", 5)


                    .param("limit", 2)


# Remember to change the equalTo() as well

# Code looks like this


    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .param("userId", 1)
                    .param("limit", 5)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(5));

        RestAssured
                .given()
                    .param("userId", 2)
                    .param("limit", 2)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(2));

    }


# run the code and show

# Search for "id" in the response

# Should be 5 + 2 = 7 instances


-----------------------------------------------
# Use multiple query params using the queryParam() (v08)


# Change all param() to queryParam()

# Code looks like this


    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .queryParam("userId", 1)
                    .queryParam("limit", 5)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(5));

        RestAssured
                .given()
                    .queryParam("userId", 2)
                    .queryParam("limit", 2)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(2));

    }


# run and show































