package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String STORE_CART_URL = "https://fakestoreapi.com/carts";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .queryParam("userId", 1)
                    .queryParam("limit", 5)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(5));

        RestAssured
                .given()
                    .queryParam("userId", 2)
                    .queryParam("limit", 2)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(2));

    }

}
