package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String COMPONENT_ID_URL = "https://fakestoreapi.com/{component}/{id}";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .pathParam("component", "products")
                    .pathParam("id", 1)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(1));

        RestAssured
                .given()
                    .pathParam("component", "products")
                    .pathParam("id", 4)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(4));


        RestAssured
                .given()
                    .pathParam("component", "carts")
                    .pathParam("id", 2)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                .body("id", equalTo(2));


        RestAssured
                .given()
                    .pathParam("component", "carts")
                    .pathParam("id", 6)
                .when()
                    .get(COMPONENT_ID_URL)
                .then()
                    .statusCode(200)
                    .body("id", equalTo(6));

    }

}
