package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String PRODUCT_ONE_URL = "https://fakestoreapi.com/products/1";
    private static final String PRODUCT_TWO_URL = "https://fakestoreapi.com/products/2";
    private static final String PRODUCT_FIVE_URL = "https://fakestoreapi.com/products/5";

    private static final String CATEGORY_JEWELLERY_URL =
            "https://fakestoreapi.com/products/category/jewelery";

    private static final String CATEGORY_ELECTRONICS_URL =
            "https://fakestoreapi.com/products/category/electronics";

    private static final String USER_ONE_LIMIT_FIVE_CART_URL =
            "https://fakestoreapi.com/carts?userId=1&limit=5";
    private static final String USER_ONE_LIMIT_TWO_CART_URL =
            "https://fakestoreapi.com/carts?userId=1&limit=2";

    @Test
    public void testProducts() {
        RestAssured.get(PRODUCT_ONE_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(PRODUCT_TWO_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(2));

        RestAssured.get(PRODUCT_FIVE_URL)
                .then()
                .statusCode(200)
                .body("id", equalTo(5));

    }

    @Test
    public void testCategories() {
        RestAssured.get(CATEGORY_JEWELLERY_URL)
                .then()
                .statusCode(200)
                .body("size()", is(4));

        RestAssured.get(CATEGORY_ELECTRONICS_URL)
                .then()
                .statusCode(200)
                .body("size()", is(6));
    }


    @Test
    public void testCartUserAndLimit() {
        RestAssured.get(USER_ONE_LIMIT_FIVE_CART_URL)
                .then()
                .statusCode(200)
                .body("size()", is(5));

        RestAssured.get(USER_ONE_LIMIT_TWO_CART_URL)
                .then()
                .statusCode(200)
                .body("size()", is(2));
    }

}
