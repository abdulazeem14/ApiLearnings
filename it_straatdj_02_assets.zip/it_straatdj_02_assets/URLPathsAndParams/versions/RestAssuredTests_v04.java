package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String COMPONENT_ID_URL = "https://fakestoreapi.com/{component}/{id}";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured.get(COMPONENT_ID_URL, "products", 1)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(COMPONENT_ID_URL, "products", 11)
                .then()
                .statusCode(200)
                .body("id", equalTo(11));

        RestAssured.get(COMPONENT_ID_URL, "carts", 2)
                .then()
                .statusCode(200)
                .body("id", equalTo(2));

        RestAssured.get(COMPONENT_ID_URL, "carts", 6)
                .then()
                .statusCode(200)
                .body("id", equalTo(6));

    }

}
