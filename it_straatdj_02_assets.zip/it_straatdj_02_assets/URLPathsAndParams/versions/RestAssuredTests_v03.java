package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String SINGLE_PRODUCTS_URL = "https://fakestoreapi.com/products/{id}";

    @Test
    public void testProductsWithPathParams() {
        RestAssured.get(SINGLE_PRODUCTS_URL, 1)
                .then()
                .statusCode(200)
                .body("id", equalTo(1));

        RestAssured.get(SINGLE_PRODUCTS_URL, 3)
                .then()
                .statusCode(200)
                .body("id", equalTo(3));

        RestAssured.get(SINGLE_PRODUCTS_URL, 11)
                .then()
                .statusCode(200)
                .body("id", equalTo(11));

    }

}
