package org.loonycorn.restassuredtests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class RestAssuredTests {

    private static final String STORE_CART_URL = "https://fakestoreapi.com/carts";

    @Test
    public void testComponentsWithPathParams() {
        RestAssured
                .given()
                    .param("userId", 1)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(7));

        RestAssured
                .given()
                    .param("userId", 2)
                .when()
                    .get(STORE_CART_URL)
                    .prettyPeek()
                .then()
                    .statusCode(200)
                    .body("size()", equalTo(7));

    }

}
