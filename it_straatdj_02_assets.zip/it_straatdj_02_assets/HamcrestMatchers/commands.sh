-----------------------------------------------
Hamcrest Matchers
-----------------------------------------------

# Hamcrest is a framework for writing matcher objects in Java. It's commonly used in testing frameworks like JUnit, TestNG, and also in libraries like Mockito and RestAssured. Matchers are objects that allow you to make flexible assertions in your tests. They provide a way to declaratively state the expected outcome of a test.

# Here are some key features and aspects of Hamcrest:

# Declarative Matchers: Hamcrest provides a set of predefined matchers that you can use to express assertions in a more human-readable and expressive way. For example, instead of writing complex conditional statements, you can simply use Hamcrest matchers like equalTo, hasItem, containsString, etc.

# Easy Integration: It integrates seamlessly with popular testing frameworks like JUnit and TestNG. Most of these frameworks have built-in support for Hamcrest, making it easy to use matchers in your test assertions.

# Extensibility: You can easily create custom matchers to fit your specific testing needs. This allows you to write more domain-specific and readable tests.

# Error Reporting: Hamcrest provides informative error messages when assertions fail, making it easier to diagnose and fix issues in your tests.


---------------------------------

# On IntelliJ

# Show that we have a new class HamcrestMatcherTests

# Go to

https://mvnrepository.com/


# Search for Hamcrest

# Click on the first result and show this is the dependency we would have to add if we are using Hamcrest standalone

# Come back to IntelliJ

# Expand external libraries and show that Hamcrest 2.2 is already present in this list

----------------------------------
# Hamcrest matching for numbers (v0)


import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;


public class HamcrestMatcherTests {

    @Test
    public void testEqualTo() {
        assertThat(200, equalTo(200));
    }
}

# Run and show

# Add a test

    @Test
    public void testGreaterThan200() {
        assertThat(201, greaterThan(200));
    }


# Change to 300 and show the failure

# Add another test

    @Test
    public void testGreaterThanEqualTo200() {
        assertThat(200, greaterThanOrEqualTo(200));
    }


# Run and show

# Add two more tests


    @Test
    public void testLessThan300() {
        assertThat(200, lessThan(300));
    }

    @Test
    public void testLessThanOrEqualTo300() {
        assertThat(300, lessThanOrEqualTo(300));
    }

# Run and show (run the whole class)


# Test closeTo()

    @Test
    public void testCloseTo() {
        assertThat(10.5, closeTo(10, 0.5));
        assertThat(9.6, closeTo(10, 0.5));
    }

# Run and show that this should pass

# Add this (this should fail)

        assertThat(10.7, closeTo(10, 0.5));

# Replace with this

        assertThat(9.4, closeTo(10, 0.5));

# Should fail again

# Add this to to test between(), note we are combining Matchers here


    @Test
    public void testBetween() {
        assertThat(201, allOf(greaterThanOrEqualTo(200), lessThanOrEqualTo(300)));
    }


 # Test either again with combining matchers

     @Test
    public void testEither() {
        assertThat(200, either(equalTo(200)).or(equalTo(201)));
    }


----------------------------------
# Hamcrest matching for strings (v2)


public class HamcrestMatcherTests {

    @Test
    public void testIfStringEqual() {
        String testString = "Test";
        assertThat(testString, equalTo("Test"));
    }

    @Test
    public void testIfStringEqualIgnoreCase() {
        String testString = "Test";
        assertThat(testString, equalToIgnoringCase("test"));
    }
}

# run and show

# Add tests for contains(), startsWith(), endsWith()

# All of these have the IgnoringCase option

    @Test
    public void testIfStringContainsSubstring() {
        String testString = "Hello Hamcrest";
        assertThat(testString, containsString("Hamcrest"));
    }

    @Test
    public void testIfStringContainsSubstringIgnoringCase() {
        String testString = "Hello Hamcrest";
        assertThat(testString, containsStringIgnoringCase("hamcrest"));
    }

    @Test
    public void testIfStringStartsWithPrefix() {
        String testString = "Hello Hamcrest";
        assertThat(testString, startsWith("Hello"));
    }

    @Test
    public void testIfStringEndsWithSuffix() {
        String testString = "Hello Hamcrest";
        assertThat(testString, endsWith("Hamcrest"));
    }


# Run the entire test suite and show

# Test regular expressions


    @Test
    public void testIfStringMatchesPattern() {
        String testString = "test@example.com";
        assertThat(testString, matchesPattern("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"));
    }

# Change the email so the test fails and show


# Empty and blank string (isEmptyString() is deprecated)

    @Test
    public void testIfStringIsEmpty() {
        String testString = "";
        assertThat(testString, is(emptyString()));
    }

    @Test
    public void testIfStringIsBlank() {
        String testString = "   ";
        assertThat(testString, is(blankString()));
    }


# Run all tests and show

# Ignoring and compressing whitespace


    @Test
    public void testIfStringEqualToCompressingWhiteSpace() {
        String testString = "  Hello Hamcrest ";
        assertThat(testString, equalToCompressingWhiteSpace("Hello Hamcrest"));

        testString = "Hello   Hamcrest";
        assertThat(testString, equalToCompressingWhiteSpace("Hello Hamcrest"));
    }

# Run all tests and show

----------------------------------
# Hamcrest matching for collections (v3)

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testIfCollectionEmpty() {
        List<String> namesList = new ArrayList<>();

        assertThat(namesList, empty());
    }

}

# Run and show

# Test size of collection


    @Test
    public void testIfCollectionOfCertainSize() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasSize(5));
    }


# Run the whole suite and show

	@Test
    public void testIfCollectionContainsItem() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasItem("Nora"));
    }

    @Test
    public void testIfCollectionContainsItems() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasItems("Elsie", "Peter"));
    }


# Run the whole suite and show

# Change something in the second test so it fails (change Peter to Pete)

# Make sure to change it back

# Check items in order and in any order


    @Test
    public void testIfCollectionContainsItemsInOrder() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, contains("John", "Elsie", "Nora", "Peter", "Charles"));
    }

    @Test
    public void testIfCollectionContainsItemsInAnyOrder() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, containsInAnyOrder("Peter", "Nora", "Elsie", "Charles", "John"));
    }

# Run and show

# Test if every item matches


    @Test
    public void testIfEveryItemMatches() {
        List<String> namesList = Arrays.asList("John", "Julie", "Jackson", "Jane", "Joseph");

        assertThat(namesList, everyItem(startsWith("J")));
    }


# Change one name and show that the test fails
# Remember to change it back

# Testing maps


    @Test
    public void testIfMapHasKey() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasKey("John"));
    }

    @Test
    public void testIfMapHasValue() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasValue(25));
    }

    @Test
    public void testIfMapHasEntry() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasEntry("John", 30));
    }


# Test arrays


    @Test
    public void testIfArrayOfCertainSize() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayWithSize(5));
    }

    @Test
    public void testIfArrayHasItem() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, hasItemInArray("Charles"));
    }

    @Test
    public void testIfArrayHasItemsInOrder() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayContaining("John", "Elsie", "Nora", "Peter", "Charles"));
    }

    @Test
    public void testIfArrayHasItemsInAnyOrder() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayContainingInAnyOrder("John", "Peter", "Charles", "Elsie", "Nora"));
    }



----------------------------------
# Hamcrest matching for objects and beans (v4)

# Set up a Student object under main/java/org/loonycorn

package org.loonycorn;

import java.util.Objects;

public class Student {
    private String name;
    private String major;
    private double gpa;

    // Constructor
    public Student(String name, String major, double gpa) {
        this.name = name;
        this.major = major;
        this.gpa = gpa;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name=" + name + 
                ", major=" + major + 
                ", gpa=" + gpa +
                "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Student student = (Student) o;

        return Double.compare(student.gpa, gpa) == 0 &&
                Objects.equals(name, student.name) &&
                Objects.equals(major, student.major);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, major, gpa);
    }
}


# Add some tests

import org.loonycorn.Student;
import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testStudentObject() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, equalTo(new Student("Jessica Lang", "Computer Science", 3.8)));
    }
}


# Run and show

# Add more tests for null and instance of


    @Test
    public void testStudentObjectInstanceOf() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, instanceOf(Student.class));
    }

    @Test
    public void testStudentObjectNullValue() {
        Student nullStudent = null;
        
        assertThat(nullStudent, nullValue());
    }

    @Test
    public void testStudentObjectNotNullValue() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);
        
        assertThat(student, notNullValue());
    }


    @Test
    public void testStudentObjectSameInstance() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);
        Student sameStudent = student;
        
        assertThat(student, sameInstance(sameStudent));
    }

# Run all tests and show

# Can check toString


    @Test
    public void testStudentObjectHasToString() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, hasToString("Student{name=Jessica Lang, major=Computer Science, gpa=3.8}"));
    }


# Check properties (this is useful when using Java Beans)


    @Test
    public void testStudentObjectHasProperty() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, hasProperty("name", equalTo("Jessica Lang")));
        assertThat(student, hasProperty("major", equalTo("Computer Science")));
        assertThat(student, hasProperty("gpa", equalTo(3.8)));
    }

# Run one test and show

# Can do all properties of a bean

    @Test
    public void testStudentObjectsHaveSameProperties() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);
        Student anotherStudent = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, samePropertyValuesAs(anotherStudent));
    }

# Run one test and show

# Change something in anotherStudent and show failure




































