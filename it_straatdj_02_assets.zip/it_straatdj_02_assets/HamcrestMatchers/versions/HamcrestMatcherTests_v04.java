package org.loonycorn.restassuredtests;

import org.loonycorn.Student;
import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testStudentObject() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, equalTo(new Student("Jessica Lang", "Computer Science", 3.8)));
    }

    @Test
    public void testStudentObjectInstanceOf() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, instanceOf(Student.class));
    }

    @Test
    public void testStudentObjectNullValue() {
        Student nullStudent = null;

        assertThat(nullStudent, nullValue());
    }

    @Test
    public void testStudentObjectNotNullValue() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, notNullValue());
    }


    @Test
    public void testStudentObjectSameInstance() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);
        Student sameStudent = student;

        assertThat(student, sameInstance(sameStudent));
    }

    @Test
    public void testStudentObjectHasToString() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, hasToString("Student{name=Jessica Lang, major=Computer Science, gpa=3.8}"));
    }

    @Test
    public void testStudentObjectHasProperty() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, hasProperty("name", equalTo("Jessica Lang")));
        assertThat(student, hasProperty("major", equalTo("Computer Science")));
        assertThat(student, hasProperty("gpa", equalTo(3.8)));
    }


    @Test
    public void testStudentObjectsHaveSameProperties() {
        Student student = new Student("Jessica Lang", "Computer Science", 3.8);
        Student anotherStudent = new Student("Jessica Lang", "Computer Science", 3.8);

        assertThat(student, samePropertyValuesAs(anotherStudent));
    }

}
