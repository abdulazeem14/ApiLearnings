package org.loonycorn.restassuredtests;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testIfCollectionEmpty() {
        List<String> namesList = new ArrayList<>();

        assertThat(namesList, empty());
    }

    @Test
    public void testIfCollectionOfCertainSize() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasSize(5));
    }

    @Test
    public void testIfCollectionContainsItem() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasItem("Nora"));
    }

    @Test
    public void testIfCollectionContainsItems() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, hasItems("Elsie", "Peter"));
    }

    @Test
    public void testIfCollectionContainsItemsInOrder() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, contains("John", "Elsie", "Nora", "Peter", "Charles"));
    }

    @Test
    public void testIfCollectionContainsItemsInAnyOrder() {
        List<String> namesList = Arrays.asList("John", "Elsie", "Nora", "Peter", "Charles");

        assertThat(namesList, containsInAnyOrder("Peter", "Nora", "Elsie", "Charles", "John"));
    }


    @Test
    public void testIfEveryItemMatches() {
        List<String> namesList = Arrays.asList("John", "Julie", "Jessica", "Joseph");

        assertThat(namesList, everyItem(startsWith("J")));
    }

    @Test
    public void testIfMapHasKey() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasKey("John"));
    }

    @Test
    public void testIfMapHasValue() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasValue(25));
    }

    @Test
    public void testIfMapHasEntry() {
        Map<String, Integer> agesMap = new HashMap<>();
        agesMap.put("John", 30);
        agesMap.put("Elsie", 25);
        agesMap.put("Nora", 20);

        assertThat(agesMap, hasEntry("John", 30));
    }

    @Test
    public void testIfArrayOfCertainSize() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayWithSize(5));
    }

    @Test
    public void testIfArrayHasItem() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, hasItemInArray("Charles"));
    }

    @Test
    public void testIfArrayHasItemsInOrder() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayContaining("John", "Elsie", "Nora", "Peter", "Charles"));
    }

    @Test
    public void testIfArrayHasItemsInAnyOrder() {
        String[] namesArray = {"John", "Elsie", "Nora", "Peter", "Charles"};

        assertThat(namesArray, arrayContainingInAnyOrder("John", "Peter", "Charles", "Elsie", "Nora"));
    }

}
