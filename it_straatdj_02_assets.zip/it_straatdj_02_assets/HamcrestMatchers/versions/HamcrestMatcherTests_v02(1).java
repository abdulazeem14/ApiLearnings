package org.loonycorn.restassuredtests;

import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testIfStringEqual() {
        String testString = "Test";
        assertThat(testString, equalTo("Test"));
    }

    @Test
    public void testIfStringEqualIgnoreCase() {
        String testString = "Test";
        assertThat(testString, equalToIgnoringCase("test"));
    }

    @Test
    public void testIfStringContainsSubstring() {
        String testString = "Hello Hamcrest";
        assertThat(testString, containsString("Hamcrest"));
    }

    @Test
    public void testIfStringContainsSubstringIgnoringCase() {
        String testString = "Hello Hamcrest";
        assertThat(testString, containsStringIgnoringCase("hamcrest"));
    }

    @Test
    public void testIfStringStartsWithPrefix() {
        String testString = "Hello Hamcrest";
        assertThat(testString, startsWith("Hello"));
    }

    @Test
    public void testIfStringEndsWithSuffix() {
        String testString = "Hello Hamcrest";
        assertThat(testString, endsWith("Hamcrest"));
    }

    @Test
    public void testIfStringMatchesPattern() {
        String testString = "test@example.com";
        assertThat(testString, matchesPattern("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"));
    }

    @Test
    public void testIfStringIsEmpty() {
        String testString = "";
        assertThat(testString, is(emptyString()));
    }

    @Test
    public void testIfStringIsBlank() {
        String testString = "   ";
        assertThat(testString, is(blankString()));
    }

    @Test
    public void testIfStringEqualToCompressingWhiteSpace() {
        String testString = "  Hello Hamcrest ";
        assertThat(testString, equalToCompressingWhiteSpace("Hello Hamcrest"));

        testString = "Hello   Hamcrest";
        assertThat(testString, equalToCompressingWhiteSpace("Hello Hamcrest"));
    }
}
