package org.loonycorn.restassuredtests;

import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcherTests {

    @Test
    public void testEqualTo() {
        assertThat(200, equalTo(200));
    }

    @Test
    public void testGreaterThan200() {
        assertThat(201, greaterThan(200));
    }

    @Test
    public void testGreaterThanEqualTo200() {
        assertThat(200, greaterThanOrEqualTo(200));
    }

    @Test
    public void testLessThan300() {
        assertThat(200, lessThan(300));
    }

    @Test
    public void testLessThanOrEqualTo300() {
        assertThat(300, lessThanOrEqualTo(300));
    }

    @Test
    public void testCloseTo() {
        assertThat(10.5, closeTo(10, 0.5));
        assertThat(9.6, closeTo(10, 0.5));

//        assertThat(10.7, closeTo(10, 0.5));
//        assertThat(9.4, closeTo(10, 0.5));
    }

    @Test
    public void testBetween() {
        assertThat(201, allOf(greaterThanOrEqualTo(200), lessThanOrEqualTo(300)));
    }

    @Test
    public void testEither() {
        assertThat(200, either(equalTo(200)).or(equalTo(201)));
    }
}
